Hi Kamil, 

here is an example, where STADO don't recognize all executions of an cursor.

The following code was executed and tcpdump was started before the app connects to the database. 

	public static final String SQL = "Select nachname,name from ZD01_MIA where id = ?";

    try (PreparedStatement prepareStatement = connection.prepareStatement(SQL)) {
      for (int id = 1; id <= 1000; id++) {

        prepareStatement.setInt(1, id);
        try (ResultSet rs = prepareStatement.executeQuery()) {
          while (rs.next()) {

          }

        }
      }

    }
	
So the cursor is executed 1000 times without an close. This is typical in JDBC programming to avoid parse costs. 
The same can be achieved with: Quote DOC:

"
The 11.2 drivers also add a new property to enable the Implicit Statement Cache.

oracle.jdbc.implicitStatementCacheSize

The value of the property is an integer string, e.g. “100”. It is the initial size of the statement cache. Setting the property to a positive value enables the Implicit Statement Cache. The default is “0”. The property can be set as a System property via -D or as a connection property via getConnection
" 

So even if you close the prepared statement/ cursor in the program Oracle keeps it open to speed up rexecutes. 

STADO seems to have a problem recognizing this:

1000 executions but only one is recognized: 

...\bin\stado.exe -f kamil_ps_reexecute.pcap -i 10.1.179.13 -p 1521
SQL ID          Ratio           Ela App (ms)    Ela Net(ms)     Exec    Ela Stddev App  Ela App/Exec    Ela Stddev Net  Ela Net/Exec    P       S       RC
------------------------------------------------------------------------------------------------------------------------------------------------------------
8cw1t670u984d   0.000000        0.634000        0.000000        1       0.000000        0.634000    0.000000    0.000000        2       1       0
9rbjw2j75qz8v   0.000000        1.768000        0.000000        1       0.000000        1.768000    0.000000    0.000000        2       1       0
1b85tb8hh2ar1   0.000000        43.315000       0.000000        1       0.000000        43.315000   0.000000    0.000000        2       1       0

Sum App Time(s): 0.045717
Sum Net Time(s): 0

No. SQLs: 3

10.1.179.13 185 kb


        Time frame:  2020-01-30 07:45:23.022484 +0100 CET  <=>  2020-01-30 07:45:23.716436 +0100 CET
        Time frame duration (s):  0.693952


	


The next beer is on you :-) 

Regards 
Daniel