Hi Kamil, 

thanks for your work. 
Here a the information regarding the pcap file:

- JDBC Application 
- tcpdump was started before app connects to the database. 

19.3 from Maven Central: 

<dependency>
  <groupId>com.oracle.ojdbc</groupId>
  <artifactId>ojdbc8</artifactId>
  <version>19.3.0.0</version>
</dependency>

- This pcap file is attached

D:\jfr\p3Cobol\prog_exec\lrm038>D:\goprojects\bin\stado.exe -f kamil.pcap -i 10.1.179.13 -p 1521
SQL ID          Ratio           Ela App (ms)    Ela Net(ms)     Exec    Ela Stddev App  Ela App/Exec    Ela Stddev Net  Ela Net/Exec    P       S       RC
------------------------------------------------------------------------------------------------------------------------------------------------------------

Sum App Time(s): 0
Sum Net Time(s): 0

No. SQLs: 0

10.1.179.13 6683 kb




I also did an test with 

<dependency>
  <groupId>com.oracle.jdbc</groupId>
  <artifactId>ojdbc7_g</artifactId>
  <version>12.1.0.2</version>
</dependency>

With the 12.1 jdbc debug jar (_g) STADO worked:

D:\jfr\p3Cobol\prog_exec\lrm038>D:\goprojects\bin\stado.exe -f kamil.pcap -i 10.1.179.13 -p 1521
SQL ID          Ratio           Ela App (ms)    Ela Net(ms)     Exec    Ela Stddev App  Ela App/Exec    Ela Stddev Net  Ela Net/Exec    P       S       RC
------------------------------------------------------------------------------------------------------------------------------------------------------------
9rbjw2j75qz8v   0.000000        2.005000        0.000000        1       0.000000        2.005000    0.000000    0.000000        2       1       0
1b85tb8hh2ar1   0.000000        42.516000       0.000000        1       0.000000        42.516000   0.000000    0.000000        2       1       0
9pb46rdcjwbfj   0.090649        8161.458000     739.832000      1       0.000000        8161.458000 0.000000    739.832000      5002    1       0

Sum App Time(s): 8.205979
Sum Net Time(s): 0.739832

No. SQLs: 3

10.1.179.13 6563 kb


        Time frame:  2020-01-29 07:41:15.717453 +0100 CET  <=>  2020-01-29 07:41:24.241513 +0100 CET
        Time frame duration (s):  8.52406
		




Hope to see you at Trivadis Performance Days or at DOAG CON this year. 

Regards 
Daniel